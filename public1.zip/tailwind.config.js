module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/**/*.html"   // 👈 include your HTML files too
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
